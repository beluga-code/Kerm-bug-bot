module.exports = {
modul: {
	axios: require('axios'),
	boom: require('@hapi/boom'),
	baileys: require('@adiwajshing/baileys'), 
	chalk: require('chalk'),
	cheerio: require('cheerio'),
	child_process: require('child_process'),
	fs: require('fs'),
	fetch: require('node-fetch'),
	FormData: require('form-data'),
	FileType: require('file-type'),
	process: require('process'),
	PhoneNumber: require('awesome-phonenumber')
}
}